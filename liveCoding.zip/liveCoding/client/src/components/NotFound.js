import React from 'react'
import PropTypes from 'prop-types'

const NotFound = (props) => {
  return (

    <h2> Page Not FOund</h2>
  )
}

export default NotFound
